package com.example.socialmediaclash;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView youtubeButton,facebookButton,whatsappButton,instagramButton,googleButton,snapchatButton,
            telegramButton,twitterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();


        youtubeButton = findViewById(R.id.youtubeButton);
        facebookButton = findViewById(R.id.facebookButton);
        whatsappButton = findViewById(R.id.whatsappButton);
        instagramButton = findViewById(R.id.instagramButton);
        googleButton = findViewById(R.id.googleButton);
        snapchatButton = findViewById(R.id.snapchatButton);
        telegramButton = findViewById(R.id.telegramButton);
        twitterButton = findViewById(R.id.twitterButton);

        youtubeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.youtube.com/");

            }

        });

        facebookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.facebook.com/");

            }

        });

        whatsappButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.whatsapp.com/");

            }

        });

        instagramButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.instagram.com/");

            }

        });

        googleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.google.com/");

            }

        });

        snapchatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.snapchat.com/");

            }

        });

        telegramButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.telegram.com/");

            }

        });

        twitterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.twitter.com/");

            }

        });




    }
        public void gotoUrl(String s)
        {
            Uri uri=Uri.parse(s);
            startActivity(new Intent(Intent.ACTION_VIEW,uri));
        }

    }
